import React from 'react';
import {
  Typography,
  Layout,
  Card,
  Form,
  Input,
  Button,
  notification,
  InputNumber,
  Upload,
  Tag,
  Tooltip,
} from 'antd';
import { InputRef } from 'antd';
import { PlusOutlined, UploadOutlined } from '@ant-design/icons';

const { Title, Paragraph } = Typography;
const { Content } = Layout;
const { TextArea } = Input;

// Define a type for your form values
interface PropertyFormValues {
  propertyName: string;
  propertyAddress: string;
  propertyDescription: string;
  maxGuests: number;
  numRooms: number;
  propertyPhotos?: any; // The type for Upload can be complex, `any` is a quick fix
}

const HostCampRegister: React.FC = () => {
  // Corrected onFinish handler with a type annotation for 'values'
  const onFinish = (values: PropertyFormValues) => {
    console.log('Received values:', values);
    notification.success({
      message: 'Property Registration Submitted',
      description: `"${values.propertyName}" has been submitted for review.`,
    });
    // In a real application, you would send this data to a backend.
  };

  const [tags, setTags] = React.useState<string[]>([]);
  const [inputVisible, setInputVisible] = React.useState(false);
  const [inputValue, setInputValue] = React.useState('');
  const inputRef = React.useRef<InputRef>(null);

  React.useEffect(() => {
    if (inputVisible) {
      inputRef.current?.focus();
    }
  }, [inputVisible]);

  const handleClose = (removedTag: string) => {
    const newTags = tags.filter((tag) => tag !== removedTag);
    setTags(newTags);
  };

  const showInput = () => {
    setInputVisible(true);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setInputValue(e.target.value);
  };

  const handleInputConfirm = () => {
    if (inputValue && tags.indexOf(inputValue) === -1) {
      setTags([...tags, inputValue]);
    }
    setInputVisible(false);
    setInputValue('');
  };

  const handleFileUpload = (info: any) => {
    if (info.file.status !== 'uploading') {
      console.log(info.file, info.fileList);
    }
    if (info.file.status === 'done') {
      notification.success({
        message: 'Photo Upload Success',
        description: `${info.file.name} uploaded successfully.`,
      });
    } else if (info.file.status === 'error') {
      notification.error({
        message: 'Photo Upload Failed',
        description: `${info.file.name} upload failed.`,
      });
    }
  };

  return (
    <Layout className="site-layout p-6" style={{ minHeight: '100vh' }}>
      <Content>
        <Card>
          <Title level={2}>Register a New Property</Title>
          <Paragraph>Fill out the form below with the details of your new property.</Paragraph>
          <Form
            name="register_property_form"
            layout="vertical"
            onFinish={onFinish}
            autoComplete="off"
            className="mt-4"
          >
            <Form.Item
              name="propertyName"
              label="Property Name"
              rules={[{ required: true, message: 'Please enter the property name!' }]}
            >
              <Input placeholder="e.g., Cozy Mountain Cabin" />
            </Form.Item>
            <Form.Item
              name="propertyAddress"
              label="Address"
              rules={[{ required: true, message: 'Please enter the property address!' }]}
            >
              <TextArea rows={2} placeholder="e.g., 123 Pine St, Mountainville, CO" />
            </Form.Item>
            <Form.Item
              name="propertyDescription"
              label="Description"
              rules={[{ required: true, message: 'Please provide a description!' }]}
            >
              <TextArea rows={4} placeholder="e.g., A beautiful and secluded cabin perfect for a relaxing getaway..." />
            </Form.Item>
            <Form.Item
              name="maxGuests"
              label="Max Guest Capacity"
              rules={[{ required: true, message: 'Please enter the maximum number of guests!' }]}
            >
              <InputNumber min={1} style={{ width: '100%' }} placeholder="e.g., 4" />
            </Form.Item>
            <Form.Item
              name="numRooms"
              label="Number of Rooms"
              rules={[{ required: true, message: 'Please enter the total number of rooms!' }]}
            >
              <InputNumber min={1} style={{ width: '100%' }} placeholder="e.g., 2" />
            </Form.Item>
            <Form.Item label="Hashtags">
              {tags.map((tag, index) => {
                const isLongTag = tag.length > 20;
                const tagElem = (
                  <Tag closable onClose={() => handleClose(tag)} style={{ marginBottom: '8px' }}>
                    {isLongTag ? `${tag.slice(0, 20)}...` : tag}
                  </Tag>
                );
                return isLongTag ? (
                  <Tooltip title={tag} key={tag}>{tagElem}</Tooltip>
                ) : (
                  tagElem
                );
              })}
              {inputVisible && (
                <Input
                  ref={inputRef}
                  type="text"
                  size="small"
                  className="tag-input"
                  value={inputValue}
                  onChange={handleInputChange}
                  onBlur={handleInputConfirm}
                  onPressEnter={handleInputConfirm}
                  style={{ width: '120px' }}
                />
              )}
              {!inputVisible && (
                <Tag onClick={showInput} className="site-tag-plus">
                  <PlusOutlined /> New Tag
                </Tag>
              )}
            </Form.Item>
            <Form.Item
              name="propertyPhotos"
              label="Property Photos"
              valuePropName="fileList"
              getValueFromEvent={(e: any) => e?.fileList}
              rules={[{ required: true, message: 'Please upload at least one photo!' }]}
            >
              <Upload name="photos" listType="picture" multiple beforeUpload={() => false} onChange={handleFileUpload}>
                <Button icon={<UploadOutlined />}>Click to Upload</Button>
              </Upload>
            </Form.Item>
            <Form.Item>
              <Button type="primary" htmlType="submit" icon={<PlusOutlined />} block>
                Submit Property for Review
              </Button>
            </Form.Item>
          </Form>
        </Card>
      </Content>
    </Layout>
  );
};

export default HostCampRegister;