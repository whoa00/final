import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { DatePicker, Select, Button, Divider, Typography, Image, Spin, Alert } from 'antd';
import dayjs from 'dayjs';
import locale from 'antd/es/date-picker/locale/ko_KR';

const { RangePicker } = DatePicker;
const { Text, Title, Paragraph } = Typography;

interface Campsite {
    id: number;
    slug: string;
    name: string;
    location: string;
    description: string;
    nightlyPrice: number;
    cleaningFee: number;
    images: string[];
    amenities: string[];
}

const CampsiteDetail: React.FC = () => {
    const { slug } = useParams<{ slug: string }>();
    const [campsite, setCampsite] = useState<Campsite | null>(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    const navigate = useNavigate();
    const [dates, setDates] = useState<[dayjs.Dayjs | null, dayjs.Dayjs | null]>([
        dayjs().add(1, 'day'),
        dayjs().add(3, 'day'),
    ]);
    const [guests, setGuests] = useState('성인 1명');

    useEffect(() => {
        if (!slug) {
            setError('잘못된 캠핑장 주소입니다.');
            setLoading(false);
            return;
        }

        setLoading(true);
        setError(null);

        // slug를 DestinationList와 통일
        const campsites: Campsite[] = [
            {
                id: 1,
                slug: 'lakeside-camp1',
                name: 'Lakeside Camp A',
                location: 'Lakeview',
                description: 'Beautiful lakeside camp with stunning views.',
                nightlyPrice: 50000,
                cleaningFee: 12000,
                images: [
                    'https://placehold.co/600x400/87CEEB/FFFFFF?text=Lakeside+Camp+A+Main',
                    'https://placehold.co/600x400/87CEEB/FFFFFF?text=Lakeside+Camp+A+1',
                    'https://placehold.co/600x400/87CEEB/FFFFFF?text=Lakeside+Camp+A+2',
                ],
                amenities: ['무료 Wi-Fi', '주차 가능', '화덕', '화장실'],
            },
            {
                id: 2,
                slug: 'mountain-camp1',
                name: 'Mountain Camp A',
                location: 'Mountain Peak',
                description: 'Thrilling mountain campsite.',
                nightlyPrice: 60000,
                cleaningFee: 15000,
                images: [
                    'https://placehold.co/600x400/8B4513/FFFFFF?text=Mountain+Camp+A+Main',
                    'https://placehold.co/600x400/8B4513/FFFFFF?text=Mountain+Camp+A+1',
                    'https://placehold.co/600x400/8B4513/FFFFFF?text=Mountain+Camp+A+2',
                ],
                amenities: ['전기', '주차 가능', '화장실', '바베큐장'],
            },
        ];

        const found = campsites.find((c) => c.slug === slug);
        if (!found) {
            setError('해당 캠핑장을 찾을 수 없습니다.');
            setLoading(false);
            return;
        }

        setCampsite(found);
        setLoading(false);
    }, [slug]);

    if (loading)
        return <Spin style={{ margin: '50px auto', display: 'block' }} size="large" />;

    if (error)
        return (
            <Alert
                message="에러"
                description={error}
                type="error"
                showIcon
                style={{ maxWidth: 600, margin: '30px auto' }}
            />
        );

    if (!campsite) return <div>캠핑장 정보를 찾을 수 없습니다.</div>;

    const nights = dates[0] && dates[1] ? dates[1].diff(dates[0], 'day') : 0;
    const total = campsite.nightlyPrice * nights + (nights > 0 ? campsite.cleaningFee : 0);

    return (
        <div style={{ padding: 30, maxWidth: 1200, margin: '0 auto' }}>
            <Title level={2}>{campsite.name}</Title>
            <Text type="secondary">{campsite.location}</Text>

            <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: 5, marginTop: 20, marginBottom: 30 }}>
                <Image src={campsite.images[0]} alt="main" style={{ width: '100%', height: '100%', objectFit: 'cover', borderRadius: 12 }} />
                <div style={{ display: 'grid', gridTemplateRows: '1fr 1fr', gap: 5 }}>
                    {campsite.images.slice(1, 3).map((img, idx) => (
                        <Image key={idx} src={img} alt={`sub${idx + 1}`} style={{ width: '100%', height: '100%', objectFit: 'cover', borderRadius: 12 }} />
                    ))}
                </div>
            </div>

            <div style={{ display: 'flex', gap: 40 }}>
                <div style={{ flex: 2 }}>
                    <Title level={4}>캠핑장 소개</Title>
                    <Paragraph>{campsite.description}</Paragraph>

                    <Title level={4} style={{ marginTop: 30 }}>편의시설</Title>
                    <ul>
                        {campsite.amenities.map((item, idx) => (
                            <li key={idx}>{item}</li>
                        ))}
                    </ul>
                </div>

                <div style={{ flex: '0 0 320px', border: '1px solid #ddd', borderRadius: 12, padding: 20 }}>
                    <div style={{ display: 'flex', alignItems: 'baseline', gap: 6 }}>
                        <Text strong style={{ fontSize: '1.2rem' }}>₩{campsite.nightlyPrice.toLocaleString()}</Text>
                        <Text>/박</Text>
                    </div>

                    <RangePicker locale={locale} value={dates} onChange={(val) => setDates(val as any)} style={{ width: '100%', marginTop: 10 }} />

                    <Select
                        value={guests}
                        onChange={(val) => setGuests(val)}
                        style={{ width: '100%', marginTop: 10 }}
                        options={[
                            { value: '성인 1명', label: '성인 1명' },
                            { value: '성인 2명', label: '성인 2명' },
                            { value: '성인 3명', label: '성인 3명' },
                        ]}
                    />

                    <Button
                        type="primary"
                        size="large"
                        block
                        style={{ marginTop: 15 }}
                        onClick={() => navigate(`/booking/${slug}`, { state: { campsite, dates, guests } })}
                    >
                        예약하기
                    </Button>

                    {nights > 0 && (
                        <div style={{ marginTop: 20 }}>
                            <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                                <span>{nights}박 x ₩{campsite.nightlyPrice.toLocaleString()}</span>
                                <span>₩{(campsite.nightlyPrice * nights).toLocaleString()}</span>
                            </div>
                            <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                                <span>청소비</span>
                                <span>₩{campsite.cleaningFee.toLocaleString()}</span>
                            </div>
                            <Divider />
                            <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                                <Text strong>총액</Text>
                                <Text strong>₩{total.toLocaleString()}</Text>
                            </div>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

export default CampsiteDetail;
