import React from 'react';
import { Typography, Input, Button, Card, Row, Col, DatePicker, Select } from 'antd';
import { SearchOutlined, EnvironmentOutlined, CalendarOutlined } from '@ant-design/icons';
import { useNavigate } from 'react-router-dom';
import styles from '../styles/home.module.css';

const { Title, Paragraph } = Typography;
const { RangePicker } = DatePicker;
const { Option } = Select;

const Home: React.FC = () => {
  const navigate = useNavigate();

  const onSearch = (values: any) => {
    console.log('검색 실행:', values);
  };

  // 각 destination에 categorySlug 추가
  const featuredDestinations = [
    { title: '호수 캠핑', description: '고요한 물가에서 즐기는 캠핑.', imageUrl: 'https://placehold.co/600x400/87CEEB/FFFFFF?text=%ED%98%B8%EC%88%98', categorySlug: 'lakeside-retreats' },
    { title: '산악 여행', description: '산속에서 모험을 즐기세요.', imageUrl: 'https://placehold.co/600x400/8B4513/FFFFFF?text=%EC%82%B0', categorySlug: 'mountain-escapes' },
    { title: '해변 휴양지', description: '햇살, 바다, 시원한 바람.', imageUrl: 'https://placehold.co/600x400/ADD8E6/FFFFFF?text=%ED%95%B4%EB%B3%80', categorySlug: 'beach-getaways' },
    { title: '숲속 탐험', description: '자연 속에 푹 빠져보세요.', imageUrl: 'https://placehold.co/600x400/228B22/FFFFFF?text=%EC%88%B2', categorySlug: 'forest-adventures' },
  ];

  const howItWorks = [
    { icon: <SearchOutlined />, title: '찾기', description: '수천 개의 독특한 캠핑지를 검색하세요.' },
    { icon: <CalendarOutlined />, title: '예약', description: '간편한 온라인 예약과 결제.' },
    { icon: <EnvironmentOutlined />, title: '체험', description: '당신만의 완벽한 여행을 즐기세요.' },
  ];

  return (
    <div className={styles.homePageCampspotStyle}>
      {/* Hero Section */}
      <div className={styles.heroSection}>
        <div className={styles.heroContent}>
          <Title level={1} className={styles.heroTitle}>
            당신의 완벽한 캠핑지를 찾아보세요.
          </Title>
          <Paragraph className={styles.heroSubtitle}>
            쉽고 편하게 특별한 야외 경험을 예약하세요.
          </Paragraph>
          <div className={styles.searchWidget}>
            <Input
              className={styles.searchField}
              placeholder="어디로 떠나고 싶으신가요?"
              prefix={<EnvironmentOutlined />}
              size="large"
            />
            <RangePicker
              className={styles.searchField}
              placeholder={['체크인', '체크아웃']}
              size="large"
            />
            <Select
              className={styles.searchField}
              placeholder="게스트 수"
              size="large"
              defaultValue="2"
            >
              <Option value="1">1명</Option>
              <Option value="2">2명</Option>
              <Option value="3">3명</Option>
              <Option value="4">4명 이상</Option>
            </Select>
            <Button
              type="primary"
              size="large"
              icon={<SearchOutlined />}
              className={styles.searchButton}
              onClick={() => onSearch({ location: '예시', dates: '예시', guests: '예시' })}
            >
              검색
            </Button>
          </div>
        </div>
      </div>

      {/* Featured Destinations Section */}
      <div className={styles.sectionContainer}>
        <Title level={2} className={styles.sectionTitle}>
          추천 캠핑지
        </Title>
        <Row gutter={[24, 24]} justify="center">
          {featuredDestinations.map((destination, index) => (
            <Col key={index} xs={24} sm={12} md={8} lg={6}>
              <Card
                hoverable
                className={styles.featureCard}
                cover={<img alt={destination.title} src={destination.imageUrl} className={styles.featureImage} />}
                // 한글 slug 대신 categorySlug로 이동
                onClick={() => navigate(`/destination/${destination.categorySlug}`)}
              >
                <Card.Meta
                  title={<Title level={4} className={styles.featureTitle}>{destination.title}</Title>}
                  description={<Paragraph className={styles.featureDescription}>{destination.description}</Paragraph>}
                />
              </Card>
            </Col>
          ))}
        </Row>
      </div>

      {/* How It Works Section */}
      <div className={`${styles.sectionContainer} ${styles.howItWorksSection}`}>
        <Title level={2} className={styles.sectionTitle}>
          예약 절차
        </Title>
        <Row gutter={[24, 24]} justify="center">
          {howItWorks.map((item, index) => (
            <Col key={index} xs={24} sm={8} md={8} lg={8}>
              <div className={styles.howItWorksItem}>
                <div className={styles.howItWorksIcon}>{item.icon}</div>
                <Title level={4} className={styles.howItWorksTitle}>{item.title}</Title>
                <Paragraph className={styles.howItWorksDescription}>{item.description}</Paragraph>
              </div>
            </Col>
          ))}
        </Row>
      </div>

      {/* Call to Action Section */}
      <div className={`${styles.sectionContainer} ${styles.ctaSection}`}>
        <div className={styles.ctaContent}>
          <Title level={2} className={styles.ctaTitle}>
            다음 여행을 떠날 준비가 되셨나요?
          </Title>
          <Paragraph className={styles.ctaDescription}>
            수천 개의 독특한 캠핑지를 탐험하고 오늘 바로 예약하세요.
          </Paragraph>
          <Button type="primary" size="large" className={styles.ctaButton}>
            탐험 시작하기
          </Button>
        </div>
      </div>
    </div>
  )
}

export default Home;
