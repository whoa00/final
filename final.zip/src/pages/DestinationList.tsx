import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Card, Row, Col, Typography, Spin, Alert } from 'antd';

const { Title, Paragraph } = Typography;

interface Campsite {
  id: number;
  slug: string;
  name: string;
  location: string;
  nightlyPrice: number;
  images: string[];
  categorySlug: string;
  description: string;
}

const campsitesData: Campsite[] = [
  {
    id: 1,
    slug: 'lakeside-camp1', // CampsiteDetail과 동일하게
    name: 'Lakeside Camp A',
    location: 'Lakeview',
    nightlyPrice: 50000,
    images: ['https://placehold.co/600x400/87CEEB/FFFFFF?text=Lakeside+Camp+A'],
    categorySlug: 'lakeside-retreats',
    description: 'Beautiful lakeside camp with stunning views.',
  },
    {
    id: 2,
    slug: 'lakeside-camp2', // CampsiteDetail과 동일하게
    name: 'Lakeside Camp A',
    location: 'Lakeview',
    nightlyPrice: 50000,
    images: ['https://placehold.co/600x400/87CEEB/FFFFFF?text=Lakeside+Camp+A'],
    categorySlug: 'lakeside-retreats',
    description: 'Beautiful lakeside camp with stunning views.',
  },
  {
    id: 3,
    slug: 'mountain-camp1', // CampsiteDetail과 동일하게
    name: 'Mountain Camp A',
    location: 'Mountain Peak',
    nightlyPrice: 60000,
    images: ['https://placehold.co/600x400/8B4513/FFFFFF?text=Mountain+Camp+A'],
    categorySlug: 'mountain-escapes',
    description: 'Thrilling mountain campsite.',
  },
];

const DestinationList: React.FC = () => {
  const { categorySlug } = useParams<{ categorySlug: string }>();
  const [filteredCampsites, setFilteredCampsites] = useState<Campsite[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const navigate = useNavigate();

  useEffect(() => {
    setLoading(true);
    setError(null);

    if (!categorySlug) {
      setError('잘못된 카테고리입니다.');
      setLoading(false);
      return;
    }

    const filtered = campsitesData.filter(c => c.categorySlug === categorySlug);

    if (filtered.length === 0) {
      setError('해당 카테고리에 캠핑장이 없습니다.');
    }

    setFilteredCampsites(filtered);
    setLoading(false);
  }, [categorySlug]);

  if (loading) return <Spin style={{ margin: '50px auto', display: 'block' }} size="large" />;
  if (error) return <Alert type="error" message="에러" description={error} style={{ maxWidth: 600, margin: '30px auto' }} />;

  return (
    <div style={{ padding: 30, maxWidth: 1200, margin: '0 auto' }}>
      <Title level={2} style={{ marginBottom: 30, textTransform: 'capitalize' }}>
        {categorySlug?.replace(/-/g, ' ')}
      </Title>
      <Row gutter={[24, 24]}>
        {filteredCampsites.map(campsite => (
          <Col key={campsite.id} xs={24} sm={12} md={8} lg={6}>
            <Card
              hoverable
              cover={<img alt={campsite.name} src={campsite.images[0]} style={{ borderRadius: 12 }} />}
              onClick={() => navigate(`/campsite/${campsite.slug}`)}
            >
              <Card.Meta
                title={campsite.name}
                description={
                  <>
                    <Paragraph ellipsis={{ rows: 2 }}>{campsite.description}</Paragraph>
                    <div>₩{campsite.nightlyPrice.toLocaleString()} / 박</div>
                  </>
                }
              />
            </Card>
          </Col>
        ))}
      </Row>
    </div>
  );
};

export default DestinationList;
