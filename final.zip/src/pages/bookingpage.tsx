import React from "react";
import { Card, Typography, Radio, Button, Divider, Image } from "antd";

const { Title, Text, Paragraph } = Typography;

const ReservationRequest: React.FC = () => {
  return (
    <div style={{ display: "flex", gap: 24, padding: 24, maxWidth: 1200, margin: "0 auto" }}>
      {/* 좌측 결제 프로세스 */}
      <div style={{ flex: 2 }}>
        <Card style={{ marginBottom: 16 }}>
          <Title level={4}>1. 결제 시기 선택</Title>
          <Radio.Group style={{ width: "100%" }}>
            <div style={{ padding: "8px 0" }}>
              <Radio value="now">
                <Text strong>지금 ₩205,643 결제</Text>
              </Radio>
            </div>
           
          </Radio.Group>
          <Button type="primary" block style={{ marginTop: 16 }}>
            다음
          </Button>
        </Card>

        <Card style={{ marginBottom: 16 }}>
          <Title level={4}>2. 결제 수단 추가</Title>
        </Card>

        <Card>
          <Title level={4}>3. 요청 내용 확인</Title>
        </Card>
      </div>

      {/* 우측 요약 정보 */}
      <div style={{ flex: 1 }}>
        <Card>
          <div style={{ display: "flex", gap: 12 }}>
            <Image
              src="https://placehold.co/100x80"
              alt="숙소 이미지"
              width={100}
              height={80}
              style={{ borderRadius: 8, objectFit: "cover" }}
              preview={false}
            />
            <div>
              <Text strong>#라메르 #특가 #해변정면뷰...</Text>
              <Paragraph style={{ margin: 0, fontSize: 13, color: "#666" }}>
                ★ 4.96 (후기 297개)
              </Paragraph>
            </div>
          </div>

          <Divider />

          <Paragraph style={{ marginBottom: 4 }}>
            <Text strong>취소 수수료 없음</Text>
            <br />
            1월 7일까지 무료 취소
          </Paragraph>

          <Paragraph style={{ marginBottom: 4 }}>
            <Text strong>날짜 및 게스트</Text>
            <br />
            2026년 2월 6일 ~ 8일 / 성인 1명
          </Paragraph>

          <Paragraph style={{ marginBottom: 4 }}>
            <Text strong>요금 세부 정보</Text>
            <br />2박 × ₩79,000 → ₩158,000
            <br />청소비 → ₩20,000
            <br />서비스 수수료 → ₩27,643
          </Paragraph>

          <Divider />

          <Paragraph>
            <Text strong>총액</Text> ₩205,643
          </Paragraph>
        </Card>

        <Paragraph style={{ marginTop: 16, fontSize: 13, color: "#666" }}>
          혼치 않은 기회입니다. 이 숙소는 보통 예약이 가득 차 있습니다.
        </Paragraph>
      </div>
    </div>
  );
};

export default ReservationRequest;
